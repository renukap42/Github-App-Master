```
@author Mano Sriram

GitHub API using React, Redux and Thunk.


```

[Video Link](https://www.youtube.com/watch?v=ZxJ5GHBsFBY)
