import React, { Fragment } from "react";
import Api from "./components/Api";

const App = () => {
  return (
    <Fragment>
      <Api />
    </Fragment>
  );
};

export default App;
